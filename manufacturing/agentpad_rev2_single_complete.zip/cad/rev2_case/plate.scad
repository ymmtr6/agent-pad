// Rev2 switch-retention plate: dimensional prototype, not a full enclosure.
// Coordinates match PCB front view. Place TOP at z=5 mm above PCB top.
plate_thickness = 1.5;
switch_opening = 14.0; // Tune with a one-switch fit print.
mount_hole = 2.2; // M2 clearance; compensate for printer fit if needed.
$fn = 48;

module profile() {
    hull() {
        for (x = [2, 60]) for (y = [2, 78])
            translate([x, y]) circle(r=2);
    }
}

linear_extrude(height=plate_thickness) difference() {
    profile();
    translate([21, -1]) square([20, 26]); // MCU/USB access.
    for (x = [2.5, 59.5]) for (y = [2.5, 77.5])
        translate([x, y]) circle(d=mount_hole);
    for (row = [0:2]) for (col = [0:2]) {
        // Lower-right opening clears the EC11 body.
        translate([11.95 + col*19.05, 34 + row*19.05])
            square([switch_opening, switch_opening], center=true);
    }
}
