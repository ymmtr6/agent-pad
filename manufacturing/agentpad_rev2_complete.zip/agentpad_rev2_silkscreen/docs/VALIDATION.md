# AgentPad Rev.2 validation report

KiCad standard DRC result: **PASS**

- KiCad CLI version: 9.0.8
- Lower PCB: 0 violations, 0 unconnected items
- Upper PCB: 0 violations, 0 unconnected items

## Panel profile design
- Individual board: 62 x 80 mm
- Manufacturing panel: 140 x 88 mm
- Fabricator replacement mode: every board/spacer cutting line is a fully connected closed loop
- No intentional cutting-line gaps remain; production retention is left to fabricator CAM

## RP2040-Zero-M mechanical fit
- Module envelope: 18 x 23.5 mm, entirely within the lower PCB outline
- Pre-soldered side headers use 1.0 mm plated holes on 2.54 mm pitch
- Module is installed above the lower PCB and visible through a 20 x 25 mm upper-plate notch
- Supplied FR4 spacers preserve the nominal 6.0 mm switch-plate gap while the module passes through the notch
- Upper-plate front marking: AGENTPAD REV2 on F.Silkscreen

## Rev.2 size reduction
- Width reduced from 68 mm to 62 mm while retaining 19.05 mm key pitch
- Height remains 80 mm because the bottom 14 mm openings already end 0.9 mm from the board edge
- Lower and upper functional-board exterior corners use R2 mm
- Corner spacer slots rotated 90 degrees; minimum slot-to-opening material web is 1.5 mm
- Encoder opening changed from 7.5 mm round to Rookey-style 14 x 14 mm square

## Rev.2 MX switch mounting
- Two electrical pins per switch use 1.5 mm plated holes with 2.2 mm pads
- PTH pad 1 connects to K1..K8; PTH pad 2 connects to GND
- Existing bottom-side Kailh hot-swap SMD pads remain connected for dual mounting compatibility

## Rev.2 silkscreen markings
- Text height / stroke: 1 mm / 0.15 mm
- F.Silkscreen text reads normally when viewed from the front; B.Silkscreen text is mirrored in the design and reads normally when viewed from the back
- Lower PCB labels: U1 header signals, SW1..SW8 with K1..K8/GND, and ENC1 terminals A/C/B/G/S
- Upper plate labels: AGENTPAD REV2, SW1..SW8, and ENC1
- Panel upload contains separate F_Silkscreen and B_Silkscreen Gerber files

Generator geometry checks: **PASS**

## Supplemental checks passed
- Board and cutout containment
- Route board containment
- Same-layer route clearance heuristic >= 0.20 mm
- Switch cutout non-overlap
- RP2040-Zero body envelope fit
- Panel drill and route file generation
- No overlapping F.Mask/B.Mask apertures
- No duplicate PTH coordinates; minimum PTH drill-edge spacing 1.354 mm
- Gerber and Excellon X2 file-function attributes present

## Warnings
- EC11 footprint follows KiCad/Alps EC11E geometry; confirm your purchased encoder is EC11E-compatible before soldering.
- Panel is customer-panelized. JLCPCB may apply panelization/special-board charges depending on order options.
