# QMK wiring

Direct GPIOs: GP0..GP7 = K1..K8, GP8 = encoder A, GP14 = encoder B, GP15 = encoder push.
All inputs active-low with internal pull-ups.
On-board RP2040-Zero RGB is GPIO16.
