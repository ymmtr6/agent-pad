#!/bin/sh
set -eu

project_root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
revision=${1:-rev1}
case "$revision" in
    rev1|rev2) ;;
    *) echo "usage: $0 [rev1|rev2]" >&2; exit 2 ;;
esac
slug="agentpad_${revision}"
if [ -n "${KICAD_CLI:-}" ]; then
    kicad_cli=$KICAD_CLI
elif command -v kicad-cli9 >/dev/null 2>&1; then
    kicad_cli=$(command -v kicad-cli9)
else
    kicad_cli=$(command -v kicad-cli)
fi

mkdir -p "$project_root/docs/drc"
for board_name in lower upper; do
    "$kicad_cli" pcb drc \
        --severity-all \
        --units mm \
        --format json \
        --exit-code-violations \
        --output "$project_root/docs/drc/${slug}_${board_name}-drc.json" \
        "$project_root/kicad/${slug}_${board_name}.kicad_pcb"
done
